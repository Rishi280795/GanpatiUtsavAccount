package com.ganpati.utsav

import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Vargani(
    val id: Long,
    val name: String,
    val mobile: String,
    val amount: Double,
    val mode: String,
    val date: String
)

data class Expense(
    val id: Long,
    val title: String,
    val category: String,
    val amount: Double,
    val date: String,
    val note: String
)

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var summary: TextView
    private lateinit var content: LinearLayout
    private val prefs by lazy { getSharedPreferences("ganpati_data", MODE_PRIVATE) }
    private val vargani = mutableListOf<Vargani>()
    private val expenses = mutableListOf<Expense>()
    private val dateFormat = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadData()
        buildUi()
        showDashboard()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
        }

        val title = TextView(this).apply {
            text = "🕉️ गणपती उत्सव 2026"
            textSize = 26f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 20)
        }
        root.addView(title)

        summary = TextView(this).apply {
            textSize = 18f
            setPadding(20, 20, 20, 20)
            setBackgroundColor(0xFFFFF3E0.toInt())
        }
        root.addView(summary)

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 15, 0, 15)
        }
        nav.addView(button("Dashboard") { showDashboard() })
        nav.addView(button("वर्गणी") { showVargani() })
        nav.addView(button("खर्च") { showExpenses() })
        nav.addView(button("Reports") { showReports() })
        root.addView(nav)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 13f
            minHeight = 54
            minimumHeight = 54
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, 58.dp(), 1f).apply {
                setMargins(4.dp(), 0, 4.dp(), 8.dp())
            }
        }

    private fun actionButton(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 17f
            minHeight = 60
            minimumHeight = 60
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(-1, 60.dp()).apply {
                setMargins(0, 8.dp(), 0, 8.dp())
            }
        }

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()

    private fun refreshSummary() {
        val collection = vargani.sumOf { it.amount }
        val spent = expenses.sumOf { it.amount }
        summary.text = "वर्गणी जमा: ₹%.2f\nएकूण खर्च: ₹%.2f\nशिल्लक: ₹%.2f\nवर्गणीदार: %d"
            .format(collection, spent, collection - spent, vargani.size)
    }

    private fun clearContent() = content.removeAllViews()

    private fun showDashboard() {
        refreshSummary()
        clearContent()
        addHeader("Dashboard")
        addInfo("या अॅपमधून गणपती उत्सवाची वर्गणी आणि सर्व खर्चाची नोंद ठेवा.")
        addInfo("एकूण वर्गणी: ₹%.2f".format(vargani.sumOf { it.amount }))
        addInfo("एकूण खर्च: ₹%.2f".format(expenses.sumOf { it.amount }))
        addInfo("उपलब्ध शिल्लक: ₹%.2f".format(vargani.sumOf { it.amount } - expenses.sumOf { it.amount }))
        val addV = actionButton("➕ वर्गणी जमा करा") { showVarganiDialog() }
        val addE = actionButton("➕ खर्च नोंदवा") { showExpenseDialog() }
        content.addView(addV)
        content.addView(addE)
    }

    private fun showVargani() {
        refreshSummary()
        clearContent()
        addHeader("वर्गणी / Contribution")
        content.addView(actionButton("➕ नवीन वर्गणी नोंदवा") { showVarganiDialog() })
        if (vargani.isEmpty()) addInfo("अजून कोणतीही वर्गणी नोंदवलेली नाही.")
        vargani.forEach { item ->
            val row = card(
                "👤 ${item.name}\n" +
                "मोबाईल: ${item.mobile.ifBlank { "-" }}\n" +
                "रक्कम: ₹%.2f | ${item.mode}\nदिनांक: ${item.date}".format(item.amount)
            )
            row.setOnLongClickListener {
                confirmDelete("ही वर्गणी नोंद हटवायची आहे?") {
                    vargani.remove(item); saveData(); showVargani()
                }
                true
            }
            content.addView(row)
        }
        addInfo("टीप: नोंद हटवण्यासाठी त्या नोंदीवर दीर्घ दाब (Long Press) करा.")
    }

    private fun showExpenses() {
        refreshSummary()
        clearContent()
        addHeader("खर्च / Expenses")
        content.addView(actionButton("➕ नवीन खर्च नोंदवा") { showExpenseDialog() })
        if (expenses.isEmpty()) addInfo("अजून कोणताही खर्च नोंदवलेला नाही.")
        expenses.forEach { item ->
            val row = card(
                "🧾 ${item.title}\n" +
                "वर्ग: ${item.category}\n" +
                "रक्कम: ₹%.2f | ${item.date}\n${item.note}".format(item.amount)
            )
            row.setOnLongClickListener {
                confirmDelete("हा खर्च हटवायचा आहे?") {
                    expenses.remove(item); saveData(); showExpenses()
                }
                true
            }
            content.addView(row)
        }
        addInfo("टीप: नोंद हटवण्यासाठी त्या नोंदीवर दीर्घ दाब (Long Press) करा.")
    }

    private fun showReports() {
        refreshSummary()
        clearContent()
        addHeader("Reports")
        val total = vargani.sumOf { it.amount }
        val spent = expenses.sumOf { it.amount }
        addInfo("💰 एकूण वर्गणी: ₹%.2f".format(total))
        addInfo("💸 एकूण खर्च: ₹%.2f".format(spent))
        addInfo("🟢 शिल्लक: ₹%.2f".format(total - spent))
        addInfo("👥 एकूण वर्गणीदार: ${vargani.size}")
        addInfo("🧾 एकूण खर्च नोंदी: ${expenses.size}")
        addHeader("खर्चाचे वर्गीकरण")
        val groups = expenses.groupBy { it.category }
        if (groups.isEmpty()) addInfo("खर्च उपलब्ध नाही.")
        groups.forEach { (category, list) ->
            addInfo("$category: ₹%.2f".format(list.sumOf { it.amount }))
        }
    }

    private fun addHeader(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 22f
            setPadding(0, 15, 0, 15)
        })
    }

    private fun addInfo(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 16f
            setPadding(15, 15, 15, 15)
        })
    }

    private fun card(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 16f
        setPadding(20, 20, 20, 20)
        setBackgroundColor(0xFFF5F5F5.toInt())
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, 6, 0, 6)
        layoutParams = p
    }

    private fun showVarganiDialog() {
        val layout = formLayout()
        val name = input("नाव")
        val mobile = input("मोबाईल नंबर")
        val amount = input("रक्कम", "numberDecimal")
        val mode = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Cash", "UPI", "Other"))
        }
        layout.addView(name); layout.addView(mobile); layout.addView(amount); layout.addView(mode)
        AlertDialog.Builder(this)
            .setTitle("वर्गणी नोंदवा")
            .setView(ScrollView(this).apply { addView(layout) })
            .setPositiveButton("Save") { _, _ ->
                val value = amount.text.toString().toDoubleOrNull() ?: 0.0
                if (name.text.toString().trim().isNotEmpty() && value > 0) {
                    vargani.add(Vargani(System.currentTimeMillis(), name.text.toString().trim(),
                        mobile.text.toString().trim(), value, mode.selectedItem.toString(), dateFormat.format(Date())))
                    saveData(); showVargani()
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showExpenseDialog() {
        val layout = formLayout()
        val title = input("खर्चाचे नाव")
        val category = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Decoration", "Prasad", "Sound", "Lighting", "Pooja Material", "Food", "Mandap", "Other"))
        }
        val amount = input("रक्कम", "numberDecimal")
        val note = input("नोंद / Note")
        layout.addView(title); layout.addView(category); layout.addView(amount); layout.addView(note)
        AlertDialog.Builder(this)
            .setTitle("खर्च नोंदवा")
            .setView(ScrollView(this).apply { addView(layout) })
            .setPositiveButton("Save") { _, _ ->
                val value = amount.text.toString().toDoubleOrNull() ?: 0.0
                if (title.text.toString().trim().isNotEmpty() && value > 0) {
                    expenses.add(Expense(System.currentTimeMillis(), title.text.toString().trim(),
                        category.selectedItem.toString(), value, dateFormat.format(Date()), note.text.toString().trim()))
                    saveData(); showExpenses()
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun formLayout() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(30, 10, 30, 10)
    }

    private fun input(hint: String, type: String = "text") = EditText(this).apply {
        this.hint = hint
        if (type == "numberDecimal") inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        else inputType = android.text.InputType.TYPE_CLASS_TEXT
        setPadding(10, 15, 10, 15)
    }

    private fun confirmDelete(message: String, yes: () -> Unit) {
        AlertDialog.Builder(this).setMessage(message)
            .setPositiveButton("Delete") { _, _ -> yes() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun saveData() {
        val v = JSONArray()
        vargani.forEach {
            v.put(JSONObject().apply {
                put("id", it.id); put("name", it.name); put("mobile", it.mobile)
                put("amount", it.amount); put("mode", it.mode); put("date", it.date)
            })
        }
        val e = JSONArray()
        expenses.forEach {
            e.put(JSONObject().apply {
                put("id", it.id); put("title", it.title); put("category", it.category)
                put("amount", it.amount); put("date", it.date); put("note", it.note)
            })
        }
        prefs.edit().putString("vargani", v.toString()).putString("expenses", e.toString()).apply()
    }

    private fun loadData() {
        try {
            val v = JSONArray(prefs.getString("vargani", "[]"))
            for (i in 0 until v.length()) {
                val o = v.getJSONObject(i)
                vargani.add(Vargani(o.getLong("id"), o.getString("name"), o.getString("mobile"),
                    o.getDouble("amount"), o.getString("mode"), o.getString("date")))
            }
            val e = JSONArray(prefs.getString("expenses", "[]"))
            for (i in 0 until e.length()) {
                val o = e.getJSONObject(i)
                expenses.add(Expense(o.getLong("id"), o.getString("title"), o.getString("category"),
                    o.getDouble("amount"), o.getString("date"), o.getString("note")))
            }
        } catch (_: Exception) { }
    }
}
